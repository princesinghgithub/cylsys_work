<?php
/**
 * [urlStatusCheck description]
 * @param  [type] $urlwithoutProtocol [pass just the url without http or https and it will check for the avialability of either of them and return either http or https]
 * @return [type]                     [description]
 */

function urlStatusCheck($urlwithoutProtocol)
{
    //first check for https in the array
    $arraytoChk = array('https','http');
    foreach ($arraytoChk as $value) {

        $url = $value.'://'.$urlwithoutProtocol;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
        curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        //curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        $head = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($httpCode == 200) {
            return $url;
        }
    }

    return 'http://'.$urlwithoutProtocol;
}

function ServicePartnerUrl()
{

    //get current url
    $currentURL = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

    //get current url protocol
    $currentProtocol = 'https';

    //get param from current url
    $parts = parse_url($currentURL);

    $partnerCouponCodeQueryString = '';
    $referenceType = $_GET['ref'];
    if($referenceType == '_referral'){
        $partnerCouponCode = $_GET['cc'];
        if($partnerCouponCode){
            $partnerCouponCodeQueryString = "?ref=".$referenceType."&cc=".$partnerCouponCode;
        }
    }

    parse_str($parts['query'], $query);
    $service =  $query['service'];
    if(!$service){$service =  'editing';}
    $partner =  $query['partner'];

    //Pass key value pair for service and partners
    $arrayService = array(
                        'editing'=>'://app.editage.jp/submit-order-new-user?sl1_id=1',
                        'translation'=>'://app.editage.jp/submit-order-new-user?sl1_id=2',
                        'pss'=>'://app.editage.jp/submit-order-new-user?sl1_id=3',
                        'research'=>'://app.editage.jp/submit-order-new-user?sl1_id=4'
                        );
    $arrayPartner = array(
                        'usaco'=>'28577',
                        'alc'=>'28578'
                        );

    //check for param in array
    if (array_key_exists($partner, $arrayPartner)) {
        return $currentProtocol.$arrayService[$service].'&subPartner='.$arrayPartner[$partner].$partnerCouponCodeQueryString;
    }
    elseif (array_key_exists($service, $arrayService)){
            return $currentProtocol.$arrayService[$service].$partnerCouponCodeQueryString;
    }
    else {
        return $currentProtocol."://app.editage.jp/submit-order-new-user?subPartner=".$partnerCouponCodeQueryString;
    }
}


function getDomainProtocol(){
    $protocol = ((!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS'])!='off') || ($_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https' && $_SERVER['HTTP_X_FORWARDED_PORT'] == 443)) ? 'https://' : 'http://';
    $http_host = $_SERVER['HTTP_HOST'];
    return $protocol.$http_host;
}