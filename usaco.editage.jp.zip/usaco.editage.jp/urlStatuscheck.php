<?php
/**
 * [urlStatusCheck description]
 * @param  [type] $urlwithoutProtocol [pass just the url without http or https and it will check for the avialability of either of them and return either http or https]
 * @return [type]                     [description]
 */

/*require_once('sites/all/modules/custom/Editage/urlStatuscheck.php');
$urlsrc = urlStatusCheck('online.editage.com/sc/pss');*/
function urlStatusCheck($urlwithoutProtocol)
{

    //first check for https in the array
    $arraytoChk = array('https','http');
    foreach ($arraytoChk as $value) {

        $url = $value.'://'.$urlwithoutProtocol;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, TRUE);
        curl_setopt($ch, CURLOPT_NOBODY, TRUE); // remove body
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        //curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        $head = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($httpCode == 200) {
            return $url;
            break;
        }
    }

    return 'http://'.$urlwithoutProtocol;
}

function ServicePartnerUrl()
{

    //get current url
    $currentURL = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];

    //get current url protocol
    //$currentProtocol = $_SERVER['REQUEST_SCHEME'];
    $currentProtocol = $_SERVER['HTTP_X_FORWARDED_PROTO'];
    //get param from current url
    $parts = parse_url($currentURL);

    parse_str($parts['query'], $query);
    $service =  $query['service'];
    if(!$service){$service =  'editing';}
    $partner =  $query['partner'];

    //Pass key value pair for service and partners
    $arrayService = array(
                        'editing'=>'://online.editage.jp/submit-jobs-new-client-form/42',
                        'translation'=>'://online.editage.jp/submit-jobs-new-client-form/2157466',
                        'pss'=>'://online.editage.jp/submit-jobs-new-client-form/43'
                        );
    $arrayPartner = array(
                        'usaco'=>'7976328',
                        'alc'=>'8188451'
                        );

    //check for param in array
    if (array_key_exists($partner, $arrayPartner)) {
        return $currentProtocol.$arrayService[$service].'/'.$arrayPartner[$partner];
        break;
    }
    elseif (array_key_exists($service, $arrayService)){
            return $currentProtocol.$arrayService[$service];
    }
    else {
        return $currentProtocol."://online.editage.jp/submit-jobs-new-client-form/42/7976328";
    }
}
?>
