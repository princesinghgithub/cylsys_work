$(document).ready(function() {
	
	$(function() {
    var get_url = location.href;
    var splitUrlArray = get_url.split('/');
   // var lastPart = splitUrlArray.pop();
   // var firstPart = splitUrlArray[0];
    var folderPath = splitUrlArray[3];
    //var subFolder = splitUrlArray[4];
		
	$('nav a').removeClass("navactive");
		
	if (folderPath == '') {
        $('nav a.homelink').addClass("navactive");
    }
    if (folderPath == 'editing') {
        $('nav a.editinglink').addClass("navactive");
    }
    if (folderPath == 'pss') {
        $('nav a.psslink').addClass("navactive");
    }
    if (folderPath == 'translation') {
        $('nav a.translationlink').addClass("navactive");
    }
    if (folderPath == 'subjects.html') {
        $('nav a.subjectslink').addClass("navactive");
    }
    if (folderPath == 'testimonials') {
        $('nav a.testimonialslink').addClass("navactive");
    }
    if (folderPath == 'quality.html') {
        $('nav a.qualitylink').addClass("navactive");
    }
});

/* holiday message across site */
$( "#contact_details_wrap span.red" ).remove();
// $( "#contact_details_wrap span.red" ).css({'visibility':'visible','background-color':'#f96d03'}).text( "GW中の祝日も全て通常営業").css('display','block').css('padding','3px 5px');
//$( "#contact_details_wrap span.red" ).fadeIn().text( "１月９日（成人の日）も営業中");
    
	
	
	
    /* add pop over classes and elements*/

//$("head").append("<style> .hover-holiday{ position:relative; } </style>");
//$("#contact_details_wrap span.red").addClass('hover-holiday');
  
	/*change work timings*/
        /*if($('#contact_details_wrap')){
            $("#contact_details_wrap span").each(function(){
                if($(this).text().length > 0 && $(this).text().trim() == '月～金・祝 11:00～24:00 / 土日 12:30～21:30') {
                   $(this).text('平日・祝日 11:00～24:00 土日 12:30～21:30');
                }
            });
        }*/
//console.log($('#contact_details_wrap').text());
/*change work timings ends*/
	
//$("#contact_details_wrap span.red").append("<div class='tooltip-holiday'>12月23日(天皇誕生日)・年末年始・1月8日（成人の日）も通常営業。元旦のみ12:30~21:30の営業となります。 <div class='arrowShadow-holiday'></div></div>");

//$("head").append("<style> .tooltip-holiday{text-align: left;top: -63px;right: -1px;background-color: #bf0113;color: white;border-radius: 5px;opacity: 0;width: 275px;position: absolute;-webkit-transition: opacity 0.5s;-moz-transition: opacity 0.5s;-ms-transition: opacity 0.5s;-o-transition: opacity 0.5s;transition: opacity 0.5s; z-index: 2;padding: 10px;border: 2px solid #e16a00;background: #fcf0e5;color: black;font-family: 'MS Gothic';height: 30px;visibility: hidden;} .arrowShadow-holiday {width: 0px;height: 0px;border-left: 10px solid transparent;border-right: 10px solid transparent;border-top: 10px solid #e16a00;font-size: 0px;line-height: 0px;position: relative;top: 9px;left: 145px;z-index: 200;} </style>");
    
//$("head").append("<style> .hover-holiday:hover .tooltip-holiday {opacity:1;} </style>");
    
//$( "#contact_details_wrap span.red" ).hover(function(){
//    $('.tooltip-holiday').css('visibility', 'visible');
//});
//$("#contact_details_wrap span.red" ).mouseleave(function(){
//    $('.tooltip-holiday').css('visibility', 'hidden');
//});
/* add pop over classes and elements ends*/ 

});

/*
$(document).ready(function() {
    $('.subjectlist_table').dataTable({
        "paging": true,
        "ordering": false,
        "info": false,
        "tfoot": false,
        "lengthMenu": [
            [10, 25, 50, -1],
            [10, 25, 50, "All"]
        ]
    });
	

	

});
*/

$(document).ready(function(){
    $("#help_tooltip1").tooltip({
        title : 'The title text can be generated using Javascript'
    });
	
	
});