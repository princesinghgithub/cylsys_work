
              $(window).scroll(function () {
                $(this).scrollTop() > 0
                ? $("#myHeader").addClass("sticky")
               : $("#myHeader").removeClass("sticky");
                });
  