
 function getQueryStrings() { 
    var assoc  = {};
    var decode = function (s) { return decodeURIComponent(s.replace(/\+/g, " ")); };
    var queryString = location.search.substring(1); 
    var keyValues = queryString.split('&'); 
  
    for(var i in keyValues) { 
      var key = keyValues[i].split('=');
      if (key.length > 1) {
        assoc[decode(key[0])] = decode(key[1]);
      }
    } 
  
    return assoc; 
  } 
  function servicePartnerUrl(){
      var qs = getQueryStrings();
      var service = qs["service"]; 
      if(service=="" || service== undefined){
        service = 'editing';
      }
  
      var partner = qs["partner"];
      if(partner=="" || partner== undefined){
        partner = '';
      }
  
      var partnerCouponCodeQueryString = '';
      var referenceType = qs['ref'];
      if(referenceType == '_referral'){
          var partnerCouponCode = qs['cc'];
          if(partnerCouponCode !== "" && partnerCouponCode !== undefined){
              partnerCouponCodeQueryString = '?ref='+ referenceType + '&cc='+partnerCouponCode;
          }
      }
      var currentProtocol = 'https';
      var serviceObj = {
        'editing':'://online.editage.com/submit-order-new-user?locale=en&sl1_id=1',
        'translation':'://online.editage.com/submit-order-new-user?locale=en&sl1_id=2',
        'pss':'://online.editage.com/submit-order-new-user?locale=en&sl1_id=3',
        'research':'://online.editage.com/submit-order-new-user?locale=en&sl1_id=4'
      }
  
      var partnerObj = {
          '':'28577',
          'alc':'28578'
      }
  
      var generateUrl = "";
  
      if(partnerObj.hasOwnProperty(partner)){
        generateUrl = currentProtocol + serviceObj[service] + '/'+ partnerObj[partner] + partnerCouponCodeQueryString;
      }else if(serviceObj.hasOwnProperty(service)){
        generateUrl = currentProtocol + serviceObj[service] + partnerCouponCodeQueryString;
      }else{
        generateUrl = currentProtocol + '://app.sage.editage.com/submit-order-new-user?locale=en/'+partnerCouponCodeQueryString;
      }
  
      return generateUrl;
  }