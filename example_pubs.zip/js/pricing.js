
var pricing = function () {

    this.priceConfig = null;

    var config = {
        services:{
            premium_plus:"premium_plus",
            premium:"premium",
            advanced:"advanced",
        },
        wordCount:{
            "0-500":{
                min:0,
                max:501
            },
            "501-1500":{
                min:501,
                max:1500
            },
            "1501-3500":{
                min:1501,
                max:3500
            },
            "3501-5000":{
                min:3501,
                max:5000
            },
            "5001-8000":{
                min:5001,
                max:8000
            }
        }

    }
    this.load = function () {
        self = this;
        $.ajax({
            type: 'GET',
            url: 'json/pricing.json',
            async: false,
            success: function (response) {
                // console.log(JSON.parse(response));
                self.priceConfig = JSON.parse(response);
                self.setUp();
            }
        });
    }

    this.init = function () {
        this.load();
    };

    this.setUp = function(){
        var $calculate = $('#calculate');
        $calculate.click(this.calculatePrice);
    }

    this.calculatePrice = function (e) {
        e.preventDefault();

        //get count
        //get services

        if($('#services').val() === null){
            $('#services').addClass("highlight");
            return false;
        }

        var count = $('#count').val();
        var pack = $('#services').val();

        var advance = [];
        var premium = [];
        var premiump = [];

        var superfast 	= {};
        var fast 		= {};
        var budget 	= {};
        var range = pricecalc.returnPriceRange(count);

        var html = '';

        if(count < 1)
        {
            html = '<div id="lessthan1" style="position: absolute;    left: 0px;    color: #ff0000;    right: 0px;    font-size: 20px;    top: 100px;">Word count cannot be 0</div>';
        }else if(count <= 8000){
            switch(pack){
                case 'premium_plus':
                    let urlPP   = "/order/?center=&PlacementPage:Pricing&PlacementButton/Link:get-PLUS";
                    let wordCountPricePP = pricecalc.priceConfig['services'][pack][range];
                    for (const key in wordCountPricePP) {
                        let dataPrice = wordCountPricePP[key] * count;
                        premiump.push({
                            price:Math.round(dataPrice),
                            day:key
                        })
                    }
                    html = pricecalc.getTable(count, premiump, urlPP);
                break;
                
                case 'premium':
                    let urlP   = "/order/?center=&PlacementPage:Pricing&PlacementButton/Link:get-premium";
                    let discount = 20;

                    let wordCountPriceP = pricecalc.priceConfig['services'][pack][range];
                    for (const key in wordCountPriceP) {
                        let dataPrice = wordCountPriceP[key] * count;
                        premium.push({
                            price:Math.round(dataPrice),
                            day:key
                        })
                    }

                    html = pricecalc.getTable(count, premium, urlP, discount);
                break;
                
                case 'advanced':
                    let url   = "/order/?center=&PlacementPage:Pricing&PlacementButton/Link:get-advanced";

                    let wordCountPriceA = pricecalc.priceConfig['services'][pack][range];
                    for (const key in wordCountPriceA) {
                        let dataPrice = wordCountPriceA[key] * count;
                        advance.push({
                            price:Math.round(dataPrice),
                            day:key
                        })
                    }

                    html = pricecalc.getTable(count, advance, url);
                break;
            }
        }else{
            html = '<div class="morethan10000" style="position: absolute;    left: 0px;    color: #ff0000;    right: 0px;    font-size: 20px;    top: 100px;">For this word count, please <a href="/get-quote.html">request a custom quote</a>.</div>';
        }

        $("#showresults").hide();
		$('#showresults').html(html).fadeIn(200);
        $('.displayprice').hide();
        $('.style_data').html('');

        return false;
    };

    this.returnPriceRange = function(wordCount){
        var configWordCounts = config.wordCount;

        var returnData =""; 
        for(key in configWordCounts){
            if(configWordCounts[key]['min'] <= wordCount && configWordCounts[key]['max'] >= wordCount ){
                returnData= key;
            }
        }

        return returnData;
    };

    this.getTable = function(count, data, url, discount = 0){
        width = 100;
        prices = {};
        border = '';
        
        switch(Object.keys(data).length){
            case 1:
                width = 254;
                border = "border-right:2px solid #ae6901;";
            break;
            
            case 2:
                width = 506;
                border= "border-right:2px solid #0155a5;";
            break;
            
            case 3:
                width = 758;
            break;
        }
        
        htmlData = '<center><div style="margin: auto; position: relative; width:'+width+'px;" class="all-service-pricing">';

            for (key in data) {

                switch (Object.keys(data).length) {
                    case 1:
                        if(key == 0){
                            title   = 'Budget Plan';
                        }
                    break;

                    case 2:
                        if(key == 0){
                            title   = 'Fast Plan';
                        }else if(key == 1){
                            title   = 'Budget Plan';
                        }
                    break;

                    case 3:
                        if(key == 0){
                            title   = 'Superfast Plan';
                        }else if(key == 1){
                            title   = 'Fast Plan';
                        }else if(key == 2){
                            title   = 'Budget Plan';
                        }
                    break;
                }


                if(key == 0){
                    classes = 'table-head-orange premium_plus';
                }else if(key == 1){
                    classes = 'table-head-blue premium';
                }else if(key == 2){
                    classes = 'table-head-red advanced';
                }
                

                if(discount){
                    price = Math.round(data[key]['price'] - (data[key]['price'] * discount / 100));
                }else{
                    price = data[key]['price'];
                }

                days = (data[key]['day'] == 24)? data[key]['day']+' hrs':data[key]['day']+' days';

                htmlData += '<div class="text-center '+classes+'" style="'+border+'"><p class="bold">'+title+'</p><p class="">Get in '+days+' !</p><p class="">USD '+ price +'  </p></div>';
            }
            
            htmlData += '</div><div class="clear"></div><div class="mar-t30"><a href="get-quote.html" class="orange-action-btn text-center">Order Now<span></span></a></div><div class="clear"></div></center>';
                    
        return htmlData;
    };
};

var pricecalc = new pricing();
pricecalc.init();

