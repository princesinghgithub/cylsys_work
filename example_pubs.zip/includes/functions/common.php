<?php

function getTitle(){
	$url = $_SERVER['REQUEST_URI'];
	$uri = explode("/", $url);
	$page = explode(".", end($uri));
	return $page[0];
}