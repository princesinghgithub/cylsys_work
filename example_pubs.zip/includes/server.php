<?php

include_once 'functions/common.php';

defined('SERVER_NAME') or define('SERVER_NAME', 'http://'.$_SERVER['HTTP_HOST']);
$base_url = SERVER_NAME;
$include_path = $_SERVER['DOCUMENT_ROOT'];

$version = '?v2';

?>



