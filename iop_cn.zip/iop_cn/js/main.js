// JavaScript Document

$(function () {
// 客户心声
$('.speech .carousel').carousel({
        interval: 30000
    })
})

$('#myCarousel').carousel({
  interval: 3000,
  cycle: true
}); 

$(document).ready(function(){
	$('#nav-icon2').click(function(){
		$(this).toggleClass('open');
	});
});

//jQuery for page scrolling feature - requires jQuery Easing plugin
$(function () {
	$(document).on('click', 'a.page-scroll', function (event) {
		
		var adj = 0;
		if($(document).scrollTop() == 0){
			adj = $("#navtop").height() -10;
			//console.log(adj);
			//console.log('at zero');
		}
		var $anchor = $(this);
		//console.log($($anchor.attr('href')).offset().top);
		$('html, body').animate({
        scrollTop: $($anchor.attr('href')).offset().top - adj
      }, 1000);
		event.preventDefault();
	});
});	
	//window.addEventListener("hashchange", function() { scrollBy(0, -50) })


// When the user scrolls down 20px from the top of the document, show the button

window.onscroll = function() {scrollFunction()};
	
function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("scroll-top").style.display = "block";
    } else {
        document.getElementById("scroll-top").style.display = "none";
    }
}

// metricsupdate
$(".pull-papers").html("899,000+");$(".pull-authors").html("274,000+");$(".pull-experts").html("2,000+");$(".pull-countries").html("192");$(".pull-subject-area").html("1,200+");$(".pull-experience").html("16+");
// metricsupdate