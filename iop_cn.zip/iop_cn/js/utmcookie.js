var utmcookie = utmcookie || {};
utmcookie.config = {
    utm_source: 'utm_source',
    utm_campaign: 'utm_campaign',
    utm_medium: 'utm_medium',
    utm_matchType: 'matchtype',
    utm_keyword: 'keyword',
    cookieName: '__utrack',
    cookieLimit: 10,
    valueLimit: 15,
    replaceOffset: 5,
    cookieExpire: '1year', // 1year, 30days, 3months
    cookieDomain: '.cn.editing.iopscience.iop.org', //cross domain
    cookiePath: '/',
    istOffset: 330, // IST offset UTC +5:30
    referrerSelf: 'editage',
    referrerSearch: [
        'google',
        'yahoo',
        'bing',
        'baidu',
        'ask',
        'naver'
    ],
    direct: {
        enable: 'true',
        sourceName: 'direct',
        campaignName: 'direct',
        mediumName: window.location.pathname
    },

    organic: {
        enable: 'true',
        sourceName: 'organic',
        campaignName: 'organic',
        mediumName: document.referrer.split('.')[1]
    },

    checkDirect: true,
    utmCookieKey: {
        utm_source: 'us',
        utm_campaign: 'uc',
        utm_medium: 'um',
        utm_matchType: 'mt',
        utm_keyword: 'kw',
        time_stamp: 'dt'
    }
};

utmcookie.init = function() {
    this.checkUtmCookie();
};

utmcookie.checkUtmCookie = function() {

    var utm_source = this.getUrlParams(this.config.utm_source);
    var utm_campaign = this.getUrlParams(this.config.utm_campaign);
    var utm_medium = this.getUrlParams(this.config.utm_medium);
    var utm_matchType = this.getUrlParams(this.config.utm_matchType);
    var utm_keyword = this.getUrlParams(this.config.utm_keyword);
    var utmDataArray = this.getUtmCookie(this.config.cookieName);
    var timeval = utmcookie.getCurrentTimestamp();

    if (!this.getUrlParams(this.config.utm_source) &&
        (document.referrer == '' || document.referrer.indexOf(this.config.referrerSelf) == -1) &&
        !this.checkIfOrganic() &&
        this.config.direct.enable) {

        if (utmDataArray) {
            for (var i = 0; i < utmDataArray.length; i++) {
                if (utmDataArray[i][this.config.utmCookieKey.utm_source].indexOf(this.config.direct.sourceName) != -1) {
                    var timeStamp = new Date(parseInt(utmDataArray[i][this.config.utmCookieKey.time_stamp]));
                    var currentTimeStamp = new Date();
                    if (timeStamp.getHours() == currentTimeStamp.getHours()) {
                        this.config.checkDirect = false;
                        break;
                    }
                }
            }
        }

        if (this.config.checkDirect) {
            utm_source = this.config.direct.sourceName;
            utm_campaign = this.config.direct.campaignName;
            utm_medium = this.config.direct.mediumName;

        }
    } else if (!this.getUrlParams(this.config.utm_source) &&
        this.checkIfOrganic() &&
        this.config.organic.enable) {
        utm_source = this.getOrganicValue();
        utm_campaign = this.config.organic.campaignName;
        utm_medium = this.config.organic.sourceName;
    }

    if (utm_source) {

        if (utmDataArray.length !== 0) {
            if (utmDataArray.length < this.config.cookieLimit) {
                utmDataArray.push({
                    'us': utm_source.slice(0, this.config.valueLimit),
                    'uc': utm_campaign.slice(0, this.config.valueLimit),
                    'um': utm_medium.slice(0, this.config.valueLimit),
                    'mt': utm_matchType.slice(0, this.config.valueLimit),
                    'kw': utm_keyword.slice(0, this.config.valueLimit),
                    'dt': timeval
                });
            } else {
                utmDataArray.push({
                    'us': utm_source.slice(0, this.config.valueLimit),
                    'uc': utm_campaign.slice(0, this.config.valueLimit),
                    'um': utm_medium.slice(0, this.config.valueLimit),
                    'mt': utm_matchType.slice(0, this.config.valueLimit),
                    'kw': utm_keyword.slice(0, this.config.valueLimit),
                    'dt': timeval
                });

                utmDataArray.splice(this.config.replaceOffset, 1);
                utmDataArray.length = this.config.cookieLimit;
            }
        } else {
            utmDataArray.push({
                'us': utm_source.slice(0, this.config.valueLimit),
                'uc': utm_campaign.slice(0, this.config.valueLimit),
                'um': utm_medium.slice(0, this.config.valueLimit),
                'mt': utm_matchType.slice(0, this.config.valueLimit),
                'kw': utm_keyword.slice(0, this.config.valueLimit),
                'dt': timeval
            });
        }

        var utmDataValue = this.Base64Encode(JSON.stringify(utmDataArray));
        utmcookie.setCookie(this.config.cookieName, utmDataValue);
    }
};

utmcookie.checkIfOrganic = function() {
    for (var i = 0; i <= this.config.referrerSearch.length; i++) {
        if (document.referrer.split('.').indexOf(this.config.referrerSearch[i]) != -1) {
            return true;
        }
    }

    return false;
};

utmcookie.getOrganicValue = function() {
    for (var i = 0; i <= this.config.referrerSearch.length; i++) {
        if (document.referrer.split('.').indexOf(this.config.referrerSearch[i]) != -1) {
            return this.config.referrerSearch[i];
        }
    }

    return false;
};

utmcookie.getUtmCookie = function(cookieName) {
    var utmData = this.getCookie(cookieName);
    if (utmData) {
        return JSON.parse(this.Base64Decode(utmData));
    }
    return [];
};

utmcookie.expireDate = function() {

    var theDate = new Date();
    var oneYearLater = 0;

    switch (this.config.cookieExpire) {
        case '1year':
            oneYearLater = new Date(theDate.getTime() + 31536000000);
            break;
        case '30days':
            oneYearLater = new Date(theDate.getTime() + 30 * 24 * 60 * 60 * 1000);
            break;
        case '1months':
            oneYearLater = new Date(theDate.getTime() + 30 * 24 * 60 * 60 * 1000);
            break;
        case '3months':
            oneYearLater = new Date(theDate.getTime() + 90 * 24 * 60 * 60 * 1000);
            break;
        default:
            oneYearLater = 0;
            break;
    }

    return oneYearLater.toGMTString();
};


utmcookie.setCookie = function(name, value) {
    var expires = '';

    if (utmcookie.expireDate()) {
        expires = "; expires=" + this.expireDate();
    }
    document.cookie = name + "=" + (value || "") + expires + ";domain=" + this.config.cookieDomain + "; path=" + this.config.cookiePath;
};

utmcookie.getCookie = function(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return null;
};

utmcookie.deleteCookie = function(name) {
    document.cookie = name + '=; Max-Age=-99999999;';
};

utmcookie.getUrlParams = function(key) {
    var keyreturn = getQueryString(key);
    return keyreturn ? keyreturn : '';
};

utmcookie.getCurrentTimestamp = function() {
    var ISTTime = new Date(new Date().toLocaleString("en-US"));
    return ISTTime.getTime();
};

utmcookie.Base64Encode = function(str) {
    // first we use encodeURIComponent to get percent-encoded UTF-8,
    // then we convert the percent encodings into raw bytes which
    // can be fed into btoa.
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
        function toSolidBytes(match, p1) {
            return String.fromCharCode('0x' + p1);
        }));
};

utmcookie.Base64Decode = function(str) {
    // Going backwards: from bytestream, to percent-encoding, to original string.
    return decodeURIComponent(atob(str).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
};

var IE = (function() {
    "use strict";

    var ret, isTheBrowser,
        actualVersion,
        jscriptMap, jscriptVersion;

    isTheBrowser = false;
    jscriptMap = {
        "5.5": "5.5",
        "5.6": "6",
        "5.7": "7",
        "5.8": "8",
        "9": "9",
        "10": "10"
    };
    jscriptVersion = new Function("/*@cc_on return @_jscript_version; @*/")();

    if (jscriptVersion !== undefined) {
        isTheBrowser = true;
        actualVersion = jscriptMap[jscriptVersion];
    }

    ret = {
        isTheBrowser: isTheBrowser,
        actualVersion: actualVersion
    };

    return ret;
}());

if (IE.isTheBrowser && IE.actualVersion == 10) {
    document.onreadystatechange = function() {
        if (document.readyState === 'complete') {
            utmcookie.init();
        }
    };
} else {
    document.onreadystatechange = function() {
        if (document.readyState === 'interactive') {
            utmcookie.init();
        }
    };
}

function getQueryString() {
    var key = false,
        res = {},
        itm = null;
    var qs = location.search.substring(1);
    if (arguments.length > 0 && arguments[0].length > 1)
        key = arguments[0];

    var pattern = /([^&=]+)=([^&]*)/g;

    while (itm = pattern.exec(qs)) {
        if (key !== false && decodeURIComponent(itm[1]) === key)
            return decodeURIComponent(itm[2]);
        else if (key === false)
            res[decodeURIComponent(itm[1])] = decodeURIComponent(itm[2]);
    }
    return key === false ? res : null;
}